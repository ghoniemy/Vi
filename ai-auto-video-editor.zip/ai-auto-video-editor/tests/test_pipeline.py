import io, subprocess
from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)

def make_video(path):
    expr=r'aevalsrc=if(between(t\,0\,0.8)\,0.25*sin(2*PI*440*t)\,if(between(t\,2.0\,3.0)\,0.25*sin(2*PI*440*t)\,0)):s=16000:d=3'
    cmd=['ffmpeg','-hide_banner','-y','-f','lavfi','-i','color=c=navy:s=320x240:r=25:d=3','-f','lavfi','-i',expr,'-shortest','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k',str(path)]
    subprocess.run(cmd,check=True,capture_output=True)

def test_upload_analyze_render(tmp_path):
    sample=tmp_path/'sample.mp4'; make_video(sample)
    with sample.open('rb') as f: r=client.post('/api/upload',files={'file':('sample.mp4',f,'video/mp4')})
    assert r.status_code==200,r.text
    data=r.json(); fid=data['id']; assert data['width']==320 and data['has_audio']
    a=client.post(f'/api/analyze-silence/{fid}',data={'threshold_db':-35,'min_silence':0.25,'keep_pause':0.1})
    assert a.status_code==200,a.text
    assert len(a.json()['silences'])>=1
    srt='1\n00:00:00,100 --> 00:00:00,700\nTest caption\n'
    r=client.post(f'/api/render/{fid}',data={'aspect':'1:1','quality':'fast','remove_silence':'true','cuts_json':__import__('json').dumps(a.json()['proposed_cuts'])},files={'captions_file':('captions.srt',io.BytesIO(srt.encode()),'application/x-subrip')})
    assert r.status_code==200,r.text
    out=r.json(); assert out['validation']=='passed' and out['metadata']['width']==1080 and out['metadata']['height']==1080
    assert out['cut_count'] >= 1 and out['metadata']['duration'] < data['duration']
    d=client.get(out['download_url']); assert d.status_code==200 and len(d.content)>1000
    assert out['caption_count']>=1

def test_reject_bad_extension():
    r=client.post('/api/upload',files={'file':('bad.exe',b'nope','application/octet-stream')})
    assert r.status_code==400
