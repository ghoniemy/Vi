@echo off
cd /d "%~dp0"
where ffmpeg >nul 2>nul || (echo FFmpeg is missing. Install FFmpeg and add it to PATH.& pause & exit /b 1)
where python >nul 2>nul || (echo Python is missing. Install Python 3.10+ first.& pause & exit /b 1)
if not exist .venv python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
