from __future__ import annotations
import json, os, re, shutil, subprocess, uuid
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

ROOT = Path(__file__).resolve().parent.parent
STORAGE = ROOT / 'storage'
UPLOADS = STORAGE / 'uploads'
OUTPUTS = STORAGE / 'outputs'
PROJECTS = STORAGE / 'projects'
for p in (UPLOADS, OUTPUTS, PROJECTS): p.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD = 2 * 1024 * 1024 * 1024
ALLOWED_EXT = {'.mp4', '.mov', '.mkv', '.webm', '.avi', '.m4v'}
app = FastAPI(title='AI Auto Video Editor', version='0.1.0')
app.mount('/static', StaticFiles(directory=ROOT / 'app' / 'static'), name='static')


def run(cmd: list[str], timeout: int = 3600) -> subprocess.CompletedProcess:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise HTTPException(408, 'انتهت مهلة المعالجة. جرّب فيديو أقصر أو إعدادات أسرع.')
    if p.returncode != 0:
        detail = (p.stderr or p.stdout or 'Unknown media-processing error')[-3500:]
        raise HTTPException(500, f'فشلت معالجة الوسائط: {detail}')
    return p


def probe(path: Path) -> dict:
    p = run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)])
    data = json.loads(p.stdout)
    fmt = data.get('format', {})
    streams = data.get('streams', [])
    video = next((s for s in streams if s.get('codec_type') == 'video'), None)
    audio = next((s for s in streams if s.get('codec_type') == 'audio'), None)
    if not video: raise HTTPException(400, 'الملف لا يحتوي على مسار فيديو صالح.')
    rate = video.get('avg_frame_rate') or video.get('r_frame_rate') or '0/1'
    try:
        a,b=rate.split('/'); fps=round(float(a)/float(b), 3) if float(b) else 0
    except Exception: fps=0
    return {'filename':path.name,'duration':round(float(fmt.get('duration',0) or 0),3), 'width':video.get('width'), 'height':video.get('height'), 'fps':fps,'video_codec':video.get('codec_name'),'audio_codec':audio.get('codec_name') if audio else None,'has_audio':audio is not None,'format':fmt.get('format_name'),'size_bytes':path.stat().st_size}


def safe_path(file_id: str, kind: str = 'upload') -> Path:
    if not re.fullmatch(r'[a-f0-9]{32}', file_id): raise HTTPException(400, 'معرّف الملف غير صالح.')
    path = (UPLOADS / file_id) if kind == 'upload' else (OUTPUTS / f'{file_id}.mp4')
    if not path.is_file(): raise HTTPException(404, 'الملف غير موجود أو انتهت صلاحيته.')
    return path


@app.get('/', response_class=HTMLResponse)
def home(): return (ROOT / 'app' / 'static' / 'index.html').read_text(encoding='utf-8')

@app.get('/api/health')
def health():
    return {'status':'ok','ffmpeg':shutil.which('ffmpeg') is not None,'ffprobe':shutil.which('ffprobe') is not None,'transcription': transcription_status()}


def transcription_status():
    try:
        import faster_whisper  # noqa: F401
        return {'available':True,'engine':'faster-whisper','note':'النموذج يُنزّل عند أول استخدام وقد يحتاج موارد كبيرة.'}
    except Exception:
        return {'available':False,'engine':None,'note':'التفريغ التلقائي غير مثبت في هذه النسخة. يمكن استخدام SRT يدويًا أو تثبيت faster-whisper.'}

@app.post('/api/upload')
async def upload(file: UploadFile = File(...)):
    name = Path(file.filename or 'video.mp4').name
    if Path(name).suffix.lower() not in ALLOWED_EXT: raise HTTPException(400, 'صيغة غير مدعومة. ارفع MP4 أو MOV أو MKV أو WEBM أو AVI.')
    file_id = uuid.uuid4().hex
    dest = UPLOADS / file_id
    total = 0
    try:
        with dest.open('wb') as out:
            while True:
                chunk = await file.read(1024*1024)
                if not chunk: break
                total += len(chunk)
                if total > MAX_UPLOAD: raise HTTPException(413, 'الحد الأقصى لحجم الملف في هذه النسخة 2 جيجابايت.')
                out.write(chunk)
    except Exception:
        dest.unlink(missing_ok=True); raise
    try: meta = probe(dest)
    except Exception:
        dest.unlink(missing_ok=True); raise
    meta.update({'id':file_id,'original_name':name})
    (PROJECTS / f'{file_id}.json').write_text(json.dumps({'source':str(dest),'metadata':meta,'cuts':[],'captions':[]},ensure_ascii=False,indent=2),encoding='utf-8')
    return meta

@app.post('/api/analyze-silence/{file_id}')
def analyze_silence(file_id: str, threshold_db: float = Form(-35), min_silence: float = Form(0.65), keep_pause: float = Form(0.22)):
    src = safe_path(file_id)
    if not probe(src)['has_audio']: raise HTTPException(400,'الفيديو لا يحتوي على صوت لتحليل الصمت.')
    if not -80 <= threshold_db <= -5 or not 0.1 <= min_silence <= 10 or not 0 <= keep_pause <= 2: raise HTTPException(400,'إعدادات اكتشاف الصمت خارج النطاق المسموح.')
    p = run(['ffmpeg','-hide_banner','-i',str(src),'-af',f'silencedetect=noise={threshold_db}dB:d={min_silence}','-f','null','-'], timeout=3600)
    # ffmpeg writes filter logs to stderr; run() only returns on success.
    log = p.stderr
    duration = probe(src)['duration']
    silences=[]
    starts=re.findall(r'silence_start:\s*([\d.]+)',log)
    ends=re.findall(r'silence_end:\s*([\d.]+)',log)
    open_start=None
    events=[]
    for m in re.finditer(r'(silence_start:\s*[\d.]+|silence_end:\s*[\d.]+)',log):
        token=m.group(0)
        val=float(re.search(r'[\d.]+',token).group())
        if token.startswith('silence_start'): open_start=val
        elif open_start is not None:
            silences.append({'start':max(0,open_start),'end':min(duration,val),'duration':round(val-open_start,3)}); open_start=None
    if open_start is not None: silences.append({'start':open_start,'end':duration,'duration':round(duration-open_start,3)})
    cuts=[]
    for s in silences:
        if s['duration'] > min_silence:
            remove=max(0,s['duration']-keep_pause)
            if remove > .05:
                mid=(s['start']+s['end'])/2
                a=max(s['start'],mid-remove/2); b=min(s['end'],mid+remove/2)
                if b-a > .05: cuts.append({'start':round(a,3),'end':round(b,3),'duration':round(b-a,3),'reason':'silence'})
    proj_path=PROJECTS/f'{file_id}.json'
    proj=json.loads(proj_path.read_text(encoding='utf-8')); proj['silences']=silences; proj['cuts']=cuts
    proj['silence_settings']={'threshold_db':threshold_db,'min_silence':min_silence,'keep_pause':keep_pause}
    proj_path.write_text(json.dumps(proj,ensure_ascii=False,indent=2),encoding='utf-8')
    return {'duration':duration,'silences':silences,'proposed_cuts':cuts,'removed_seconds':round(sum(c['duration'] for c in cuts),3),'message':'تم تحليل الصوت واكتشاف مناطق الصمت فعليًا.'}


def parse_srt(s: str):
    # Supports comma or dot milliseconds, standard SRT timestamps.
    blocks=re.split(r'\n\s*\n',s.strip()) if s.strip() else []
    result=[]
    def ts(x):
        h,m,sec=x.replace('.',',').split(':'); ss,ms=sec.split(','); return int(h)*3600+int(m)*60+int(ss)+int(ms)/1000
    for block in blocks:
        lines=block.splitlines()
        ti=next((i for i,l in enumerate(lines) if '-->' in l),None)
        if ti is None: continue
        m=re.match(r'\s*(\d{2}:\d{2}:\d{2}[,.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,.]\d{3})',lines[ti])
        if not m: continue
        start,end=ts(m.group(1)),ts(m.group(2)); txt='\n'.join(lines[ti+1:]).strip()
        if end>start and txt: result.append({'start':start,'end':end,'text':txt})
    return result

def fmt_srt(t):
    t=max(0,t); ms=round(t*1000); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; sec=ms//1000; ms%=1000
    return f'{h:02}:{m:02}:{sec:02},{ms:03}'

def remap_captions(captions, cuts):
    cuts=sorted(cuts,key=lambda c:c['start']); mapped=[]
    for cap in captions:
        pieces=[(cap['start'],cap['end'])]
        for cut in cuts:
            nxt=[]
            for a,b in pieces:
                if cut['end']<=a or cut['start']>=b: nxt.append((a,b)); continue
                if a<cut['start']: nxt.append((a,cut['start']))
                if cut['end']<b: nxt.append((cut['end'],b))
            pieces=nxt
        for a,b in pieces:
            shift=sum(max(0,min(a,c['end'])-c['start']) for c in cuts)
            # Correct shift is duration of cuts entirely before this piece.
            shift=sum(c['end']-c['start'] for c in cuts if c['end']<=a)
            if b-a>=0.08: mapped.append({'start':a-shift,'end':b-shift,'text':cap['text']})
    return sorted(mapped,key=lambda x:x['start'])

@app.post('/api/render/{file_id}')
async def render(file_id: str, aspect: str = Form('source'), quality: str = Form('balanced'), remove_silence: bool = Form(True), cuts_json: str = Form(''), captions_file: Optional[UploadFile] = File(None), captions_text: str = Form('')):
    src=safe_path(file_id); meta=probe(src)
    if aspect not in {'source','9:16','16:9','1:1'}: raise HTTPException(400,'مقاس غير مدعوم.')
    if quality not in {'fast','balanced','high'}: raise HTTPException(400,'جودة غير مدعومة.')
    proj_path=PROJECTS/f'{file_id}.json'; proj=json.loads(proj_path.read_text(encoding='utf-8'))
    caps_text=captions_text
    if captions_file and captions_file.filename:
        if Path(captions_file.filename).suffix.lower() not in {'.srt','.txt'}: raise HTTPException(400,'ارفع ملف SRT أو TXT يحتوي على ترجمة SRT.')
        caps_text=(await captions_file.read()).decode('utf-8-sig','replace')
    caps=parse_srt(caps_text)
    
    if cuts_json:
        try: requested_cuts=json.loads(cuts_json)
        except Exception: raise HTTPException(400,'بيانات القصات غير صالحة.')
        if not isinstance(requested_cuts,list) or any(not isinstance(c,dict) for c in requested_cuts): raise HTTPException(400,'قائمة القصات غير صالحة.')
    else: requested_cuts=proj.get('cuts',[])
    cuts=sorted(requested_cuts if remove_silence else [],key=lambda c:float(c.get('start',0)))
    # Guard against overlapping or out-of-range cuts.
    cleaned=[]; last=0
    for c in cuts:
        a=max(last, float(c['start'])); b=min(meta['duration'],float(c['end']))
        if b-a>.04: cleaned.append({'start':a,'end':b}); last=b
    cuts=cleaned
    keep=[]; cursor=0
    for c in cuts:
        if c['start']-cursor>.04: keep.append((cursor,c['start']))
        cursor=c['end']
    if meta['duration']-cursor>.04: keep.append((cursor,meta['duration']))
    if not keep: raise HTTPException(400,'إعدادات القص ستحذف الفيديو بالكامل.')
    out_id=uuid.uuid4().hex; out=OUTPUTS/f'{out_id}.mp4'
    # Each retained segment is decoded, trimmed, reset, then concatenated to avoid timestamp drift.
    filters=[]
    for i,(a,b) in enumerate(keep):
        filters.append(f'[{i}:v]setpts=PTS-STARTPTS[v{i}]')
        if meta['has_audio']: filters.append(f'[{i}:a]asetpts=PTS-STARTPTS[a{i}]')
    if meta['has_audio']:
        concat=''.join(f'[v{i}][a{i}]' for i in range(len(keep)))
        filters.append(f'{concat}concat=n={len(keep)}:v=1:a=1[vout][aout]')
    else:
        concat=''.join(f'[v{i}]' for i in range(len(keep)))
        filters.append(f'{concat}concat=n={len(keep)}:v=1:a=0[vout]')
    if aspect!='source':
        dims={'9:16':(1080,1920),'16:9':(1920,1080),'1:1':(1080,1080)}[aspect]
        w,h=dims
        filters.append(f'[vout]scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1[vframed]')
        vlabel='vframed'
    else: vlabel='vout'
    # Subtitle file uses retimed timestamps after silence cuts; FFmpeg/libass handles RTL shaping when fonts are available.
    remapped=remap_captions(caps,cuts) if cuts else caps
    srt_path=OUTPUTS/f'{out_id}.srt'
    if remapped:
        srt_path.write_text('\n\n'.join(f'{i}\n{fmt_srt(c["start"])} --> {fmt_srt(c["end"])}\n{c["text"]}' for i,c in enumerate(remapped,1)),encoding='utf-8')
        # Escape path for ffmpeg filter syntax.
        subpath=str(srt_path).replace('\\','/').replace(':','\\:').replace("'","\\'")
        filters.append(f'[{vlabel}]subtitles=filename=\'{subpath}\':force_style=\'FontSize=26,Outline=2,Shadow=1,Alignment=2,MarginV=70\'[vsub]')
        vlabel='vsub'
    crf={'fast':'28','balanced':'23','high':'18'}[quality]
    cmd=['ffmpeg','-hide_banner','-y']
    for a,b in keep: cmd += ['-ss',f'{a:.4f}','-t',f'{b-a:.4f}','-i',str(src)]
    cmd += ['-filter_complex',';'.join(filters),'-map',f'[{vlabel}]']
    if meta['has_audio']: cmd += ['-map','[aout]','-c:a','aac','-b:a','192k']
    cmd += ['-c:v','libx264','-preset','veryfast' if quality=='fast' else 'medium','-crf',crf,'-pix_fmt','yuv420p','-movflags','+faststart',str(out)]
    try: run(cmd,timeout=7200)
    except Exception:
        out.unlink(missing_ok=True); srt_path.unlink(missing_ok=True); raise
    result=probe(out)
    if result['duration']<=0 or result['width'] is None: out.unlink(missing_ok=True); raise HTTPException(500,'الملف الناتج لا يجتاز التحقق.')
    # A full decode pass validates readability.
    run(['ffmpeg','-v','error','-i',str(out),'-f','null','-'],timeout=7200)
    (PROJECTS/f'{out_id}.json').write_text(json.dumps({'source_id':file_id,'output':str(out),'metadata':result,'cuts':cuts,'aspect':aspect,'quality':quality,'captions':remapped},ensure_ascii=False,indent=2),encoding='utf-8')
    return {'id':out_id,'download_url':f'/api/download/{out_id}','subtitle_url':f'/api/subtitles/{out_id}' if remapped else None,'metadata':result,'cut_count':len(cuts),'caption_count':len(remapped),'validation':'passed'}

@app.get('/api/download/{out_id}')
def download(out_id: str):
    p=safe_path(out_id,'output'); return FileResponse(p,media_type='video/mp4',filename='ai-auto-edited.mp4')
@app.get('/api/subtitles/{out_id}')
def subtitles(out_id: str):
    p=OUTPUTS/f'{out_id}.srt'
    if not p.is_file(): raise HTTPException(404,'ملف الترجمة غير موجود.')
    return FileResponse(p,media_type='application/x-subrip',filename='captions.srt')

@app.post('/api/transcribe/{file_id}')
def transcribe(file_id: str, language: str = Form('auto')):
    src=safe_path(file_id)
    try: from faster_whisper import WhisperModel
    except Exception: raise HTTPException(501,'التفريغ التلقائي غير متاح حاليًا لأن faster-whisper غير مثبت. يمكنك استيراد SRT الآن. تثبيت النموذج اختياري وقد يحتاج تنزيل ملفات كبيرة وذاكرة إضافية.')
    if language not in {'auto','ar','en'}: raise HTTPException(400,'اللغة غير مدعومة.')
    model_name=os.environ.get('WHISPER_MODEL','small')
    try:
        model=WhisperModel(model_name,device='cpu',compute_type='int8')
        segments,info=model.transcribe(str(src),language=None if language=='auto' else language,word_timestamps=True,vad_filter=True)
        caps=[]
        for seg in segments:
            if getattr(seg,'words',None):
                for word in seg.words: caps.append({'start':word.start,'end':word.end,'text':word.word.strip()})
            else: caps.append({'start':seg.start,'end':seg.end,'text':seg.text.strip()})
        return {'language':info.language,'language_probability':info.language_probability,'segments':caps,'model':model_name}
    except Exception as e: raise HTTPException(500,f'فشل التفريغ الصوتي: {str(e)[:500]}')

@app.get('/api/project/{file_id}')
def get_project(file_id: str):
    safe_path(file_id); p=PROJECTS/f'{file_id}.json'
    return json.loads(p.read_text(encoding='utf-8'))
