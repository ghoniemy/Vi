#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v ffmpeg >/dev/null || { echo 'FFmpeg is missing. Install FFmpeg first.'; exit 1; }
command -v python3 >/dev/null || { echo 'Python 3 is missing.'; exit 1; }
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
