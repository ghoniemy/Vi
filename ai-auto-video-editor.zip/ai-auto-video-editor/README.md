# AI Auto Video Editor — MVP

A local-first video editing pipeline built with FastAPI and FFmpeg/FFprobe.

## Implemented
- Safe video upload with generated IDs, extension allow-list, 2 GiB limit, and FFprobe inspection.
- Adjustable FFmpeg silence detection and reviewable proposed cuts.
- Apply selected cuts, concatenate retained segments, and export MP4.
- Output dimensions: source, 9:16, 16:9, or 1:1 (letterbox/pillarbox; no stretching).
- Import SRT, retime captions after cuts, burn them into the actual video, and download SRT.
- Validate output metadata and decode the entire output before success is reported.
- Optional local Arabic/English transcription endpoint with `faster-whisper` if installed.

## Run
Requires Python 3.10+, FFmpeg and FFprobe in PATH.

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000
```
Open http://127.0.0.1:8000.

## Optional transcription
Install `faster-whisper`, then POST `/api/transcribe/{file_id}` with form field `language=auto`, `ar`, or `en`. The model downloads on first use and can be slow on CPU. Basic editing requires no paid API.

## Limitations
No full multitrack timeline, motion-graphics library, licensed B-roll search, AI visual generation, advanced denoising/upscaling, user accounts, or multi-project management yet. Silence detection is acoustic rather than semantic; review cuts. Arabic burned-in caption shaping depends on fonts/libass installed in the runtime. UI reports stage-level progress rather than fake percentages. Before public hosting add authentication, HTTPS, quotas, job isolation and cleanup.
